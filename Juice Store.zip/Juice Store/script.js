const imgs = document.getElementById("imgs");
const img = document.querySelectorAll("#imgs img");
let index = 0;

function moveImg(){
    index++;
    if (index > img.length-1){
        index= 0;
    }
    

    imgs.style.transform = `translateX(${-index * 100}vw)`
}
setInterval(moveImg, 4000)

$(document).ready(function(){
    $(window).scroll(function(){
        if($(window).scrollTop()>300){
            $('#logo').css({"height": "75px","width":"75px", "transition": "height 0.5s ease 0s, width 0.5s ease 0s"})
        }
        else{
            $('#logo').css({"height": "150px","width":"150px", "transition": "height 0.5s ease 0s, width 0.5s ease 0s"})
        }
    })
})